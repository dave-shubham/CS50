<?php

    require(__DIR__ . "/../includes/config.php");

    // numerically indexed array of places
    $places = [];
    // TODO: search database for places matching $_GET["geo"], store in $places
    //print($_GET["geo"]."\n\n\n");
    
    if(is_numeric($_GET["geo"]))        //if only numeric input comes, it's only postal code
    {
        $locations=CS50::query("SELECT * FROM places WHERE postal_code LIKE ?", $_GET["geo"] . "%");
        foreach($locations as $location)
        {
            $places[]=$location;
            //print($location["place_name"]."");
        }
    }
    else
    {
            $string=$_GET["geo"];
            $tokens=[];                         //tokenizing the input for search parameters like place_name, admin_name1, admin_code1 and/or postal_code
//            echo strchr($string,",");
            if(strchr($string,",") == FALSE)
            {
                $token=strtok($string," ");
                while($token!=false)
                {
                    $tokens[]=ltrim($token," ");    //trimming leading spaces ahead of characters for better comparison 
                    $token=strtok(" ");
                }
            }
            else
            {
                $token=strtok($string,",");
                while($token!=false)
                {
                    $tokens[]=ltrim($token," ");    
                    $token=strtok(",");
                }
            }
                    /*foreach($tokens as $tok)
                    {
                        print($tok."\t".strlen($tok)."\n");
                    } */           
            //tokens[0] is place_name, if present - tokens[1] is either admin_name1 or admin_code1 and tokens[2] is postal_code or something else entirely 
            //different cases based on availibility of various search parameters
            if(empty($tokens[0]))       //name of place not entered
            {
                if(empty($tokens[2]))
                {
                    if(strlen($tokens[1]) == 2)
                    {
                        $locations=CS50::query("SELECT * FROM places WHERE (admin_code1 LIKE ?) ", $tokens[1]."%");
                    }
                    else
                    {
                        $locations=CS50::query("SELECT * FROM places WHERE (admin_name1 LIKE ?) ", $tokens[1]."%");
                    }
                }
                else
                {
                    if(strlen($tokens[1]) == 2)
                    {
                        if(is_numeric($tokens[2]))
                        {
                            $locations=CS50::query("SELECT * FROM places WHERE (admin_code1 LIKE ?) OR (postal_code LIKE ?) ", $tokens[1]."%",$tokens[2]."%");
                        }
                        else
                        {
                            $locations=CS50::query("SELECT * FROM places WHERE (admin_code1 LIKE ?) ", $tokens[1]."%");
                        }
                    }
                    else
                    {
                        if(is_numeric($tokens[2]))
                        {
                            $locations=CS50::query("SELECT * FROM places WHERE (admin_name1 LIKE ?) OR (postal_code LIKE ?) ", $tokens[1]."%",$tokens[2]."%");
                        }
                        else
                        {
                            $locations=CS50::query("SELECT * FROM places WHERE (admin_name1 LIKE ?) ", $tokens[1]."%");
                        }
                    }
                }
            }
            else
            {
                if(empty($tokens[1]) && empty($tokens[2]) )
                {
                    $locations=CS50::query("SELECT * FROM places WHERE (place_name LIKE ?)", $tokens[0]."%");
                }
                else if(empty($tokens[1]) )
                {
                    if(is_numeric($tokens[2]))
                    {
                        $locations=CS50::query("SELECT * FROM places WHERE (place_name LIKE ?) OR (postal_code LIKE ?) ", $tokens[0]."%",$tokens[2]."%");
                    }
                    else
                    {
                        $locations=CS50::query("SELECT * FROM places WHERE (place_name LIKE ?) ", $tokens[0]."%");
                    }
                }
                else if(empty($tokens[2]))
                {
                    if(strlen($tokens[1]) == 2)
                    {
                        $locations=CS50::query("SELECT * FROM places WHERE (place_name LIKE ?) OR (admin_code1 LIKE ?) ", $tokens[0]."%",$tokens[1]."%");
                    }
                    else
                    {
                        $locations=CS50::query("SELECT * FROM places WHERE (place_name LIKE ?) OR (admin_name1 LIKE ?) ", $tokens[0]."%",$tokens[1]."%");
                    }
                }
                else
                {
                    if(strlen($tokens[1]) == 2)
                    {
                        if(is_numeric($tokens[2]))
                        {
                            $locations=CS50::query("SELECT * FROM places WHERE (place_name LIKE ?) OR (admin_code1 LIKE ? ) OR (postal_code LIKE ?) ", $tokens[0]."%",$tokens[1]."%",$tokens[2]."%");
                        }
                        else
                        {
                            $locations=CS50::query("SELECT * FROM places WHERE (place_name LIKE ?) OR (admin_name1 LIKE ? ) OR (postal_code LIKE ?) ", $tokens[0]."%",$tokens[1]."%",$tokens[2]."%");
                        }
                    }
                    else
                    {
                        if(is_numeric($tokens[2]))
                        {
                            $locations=CS50::query("SELECT * FROM places WHERE (place_name LIKE ?) OR (admin_code1 LIKE ?) ", $tokens[0]."%",$tokens[1]."%");
                        }
                        else
                        {
                            $locations=CS50::query("SELECT * FROM places WHERE (place_name LIKE ?) OR (admin_name1 LIKE ?) ", $tokens[0]."%",$tokens[1]."%");
                        }                
                    }
                }
            }
            if(!empty($locations))
            {
                foreach($locations as $location)
                {
                    $places[]=$location;
                    //print($location["place_name"]."");
                }
            }
}
    
    
    

    // output places as JSON (pretty-printed for debugging convenience)
    header("Content-type: application/json");
    print(json_encode($places, JSON_PRETTY_PRINT));

?>