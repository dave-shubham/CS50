
<?php

//This is old file with crude option of entering the company symbol for getting quote



    // configuration
    require("../includes/config.php"); 

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("input_share.php", ["title" => "Get Quote"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // validate submission
        if (empty($_POST["symbol"]))
        {
            apologize("You must provide name of the share.");
        }
        else if(empty($_POST["share_amt"]))
        {
            $_POST["share_amt"]=1;
        }
        $stock = lookup($_POST["symbol"]);
        if($stock == false)
        {
            apologize("You provided wrong name of the share.");
        }
        else
        {
            $total= $stock["price"]*$_POST["share_amt"];
             // else render form
            render("view_stock.php", ["title" => "Stock Price", "symbol" => $stock["symbol"], "name" => $stock["name"], "price" => $stock["price"], "total" => $total ]);
            //echo "Symbol of stock is " . $stock["symbol"] . "\nStock Name is" . $stock["name"] . "\nPrice is" . $stock["price"] ;
            
        }
    }


?>
