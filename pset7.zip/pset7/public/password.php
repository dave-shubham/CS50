<?php

    // configuration
    require("../includes/config.php");

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("change_password.php", ["title" => "Password"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // TODO
         // validate submission
        if (empty($_POST["cpassword"]))
        {
            apologize("You must provide your current password.");
        }
        else if (empty($_POST["npassword"]))
        {
            apologize("You must provide your new password.");
        }
        else if (empty($_POST["confirmation"]))
        {
            apologize("You must provide confirmation for your new password.");
        }
        else if( $_POST["npassword"] != $_POST["confirmation"])
        {
            apologize("Your password and confirmation must match.");
        }
        
        // query database for user
        $rows = CS50::query("SELECT * FROM users WHERE id = ?",$_SESSION["id"]);

            // compare hash of user's input against hash that's in database
            if (password_verify($_POST["cpassword"], $rows[0]["hash"]))
            {
                $changePass=CS50::query("UPDATE users SET hash = ? WHERE id = ? ",password_hash($_POST["npassword"], PASSWORD_DEFAULT), $_SESSION["id"]);
                if($changePass == 1)
                {
                // redirect to portfolio
                redirect("/");
                }
            }
            else
            {
                apologize("Your entered current password is wrong.");
            }
        
    }

?>