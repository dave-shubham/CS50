<?php

    // configuration
    require("../includes/config.php"); 

  

    // render portfolio
    render("faqs.php", ["title" => "How To Use"]);

?>