<?php

    // configuration
    require("../includes/config.php"); 

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        $rows=CS50::query("SELECT * FROM symbols");
    
        $positions = [];
        foreach ($rows as $row)
        {
                $positions[] = [
                    "name" => $row["company_name"],
                    "symbol" => $row["symbol"]
                ];
        }
        
        
        
        
        // else render form
        render("buy_form.php", ["title" => "Buy Shares","positions" => $positions]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
         // validate submission
        if (empty($_POST["symbol"]))
        {
            apologize("You must provide name of the share.");
        }
        else if (empty($_POST["share_amt"]))
        {
            apologize("You must provide no. of shares.");
        }
        else if( preg_match("/^\d+$/", $_POST["share_amt"]) == false)
        {
            apologize("You must provide no. of shares in positive integers.");            
        }
        else
        {
            $stock = lookup($_POST["symbol"]);
            $totalAmt=$_POST["share_amt"]*$stock["price"];
            $curr_bal=CS50::query("SELECT cash FROM users WHERE id = ?", $_SESSION["id"]);
            if($curr_bal[0]["cash"] >= $totalAmt)
            {
               $isPresent = CS50::query("SELECT * FROM portfolio WHERE id = ? AND symbol = ?", $_SESSION["id"], $stock["symbol"] );
               
               if($isPresent[0]["symbol"] == $stock["symbol"])
                {
                    $addShares=CS50::query("UPDATE portfolio SET share_amt = share_amt + ? WHERE id = ? AND symbol = ? ", $_POST["share_amt"],$_SESSION["id"],$stock["symbol"]);
                    $deductMoney=CS50::query("UPDATE users SET cash = cash - ? WHERE id = ? ", $totalAmt,$_SESSION["id"]);
                }
                else
                {
                    $addShares=CS50::query("INSERT INTO portfolio (id, symbol, share_amt) VALUES(?, ?, ?) ", $_SESSION["id"],$stock["symbol"],$_POST["share_amt"]);
                    $deductMoney=CS50::query("UPDATE users SET cash = cash - ? WHERE id = ? ", $totalAmt,$_SESSION["id"]);
                }
                $addTransaction==CS50::query("INSERT INTO transactions (id,trans_type, symbol, share_amt,price,date_time) VALUES(?,'Buy', ?, ?,?,CURRENT_TIMESTAMP) ", $_SESSION["id"],$stock["symbol"],$_POST["share_amt"],$stock["price"]);
                
                redirect("/");
            }
            else
            {
                apologize("You have insufficient balance.");            
            }
        }
    }    
?>
