<?php

    // configuration
    require("../includes/config.php"); 

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        $rows=CS50::query("SELECT * FROM symbols");
    
        $positions = [];
        foreach ($rows as $row)
        {
                $positions[] = [
                    "name" => $row["company_name"],
                    "symbol" => $row["symbol"]
                ];
        }
        // else render form
        render("input_share.php", ["title" => "Get Quote","positions" => $positions]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // validate submission
        if (empty($_POST["symbol"]))
        {
            apologize("You must provide name of the share.");
        }
        else if(empty($_POST["share_amt"]))
        {
            $_POST["share_amt"]=1;
        }
        $balance=CS50::query("SELECT cash FROM users WHERE id = ?", $_SESSION["id"]);
        $stock = lookup($_POST["symbol"]);
        if($stock == false)
        {
            apologize("You provided wrong name of the share.");
        }
        else
        {
            $total= $stock["price"]*$_POST["share_amt"];
            $canBuy =(int) ($balance[0]["cash"]/$stock["price"]);
             // else render form
            render("view_stock.php", ["title" => "Stock Price", "symbol" => $stock["symbol"], "name" => $stock["name"], "price" => $stock["price"], "total" => $total,"canBuy" => $canBuy ]);
            //echo "Symbol of stock is " . $stock["symbol"] . "\nStock Name is" . $stock["name"] . "\nPrice is" . $stock["price"] ;
            
        }
    }


?>
