<?php

    // configuration
    require("../includes/config.php"); 

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        $rows=CS50::query("SELECT * FROM portfolio WHERE id = ?", $_SESSION["id"]);
    
        $positions = [];
        foreach ($rows as $row)
        {
            $stock = lookup($row["symbol"]);
            if ($stock !== false)
            {
                $positions[] = [
                    "name" => $stock["name"],
                    "symbol" => $row["symbol"]
                ];
            }
        }


        // else render form
        render("sell_form.php", ["positions" => $positions, "title" => "Sell Shares"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if($_POST["symbol"] == "")
        {    
            redirect("/sell.php");
        }
        else
        {
            $stock = lookup($_POST["symbol"]);
            $share_amt = CS50::query("SELECT * FROM portfolio WHERE id = ? AND symbol = ?", $_SESSION["id"],$stock["symbol"]);
            $money = $stock["price"]*$share_amt[0]["share_amt"];
            $deleteShare=CS50::query("DELETE FROM portfolio WHERE id = ? AND symbol = ?", $_SESSION["id"],$stock["symbol"]);
            $addMoney=CS50::query("UPDATE users SET cash = cash + ? WHERE id = ? ", $money,$_SESSION["id"]);
            $addTransaction==CS50::query("INSERT INTO transactions (id,trans_type, symbol, share_amt,price,date_time) VALUES(?,'Sell', ?, ?,?,CURRENT_TIMESTAMP) ", $_SESSION["id"],$stock["symbol"],$share_amt[0]["share_amt"],$stock["price"]);
            redirect("/");

        }
    }    

?>
