<?php
    // configuration
    require("../includes/config.php");
    
    // get users transactions
    $rows = CS50::query("SELECT * FROM transactions WHERE id = ?", $_SESSION["id"]);
    if(count($rows) > 0)
    {
        $transactions = [];
        foreach($rows as $row)
        {
            $transactions[] = [
                "trans_type" => $row["trans_type"],
                
                "symbol" => $row["symbol"],
                "share_amt" => $row["share_amt"],
                "price" => $row["price"],
                "date_time" => $row["date_time"]
                ];
        }
             // render history
            render("history_view.php", ["title" => "History", "transactions" => $transactions]);
    }
    else if (count($rows) == 0)
    {
        apologize("No recorded transactions for this user exist.");
    }
   
?>