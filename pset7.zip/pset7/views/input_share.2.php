<form action="quote.php" method="post">
<!--
This is old file with crude option of entering the company symbol for getting quote
-->

    <fieldset>
        <div class="form-group">
            <input autocomplete="off" title="Example GOOG for Google or C for Citigroup" autofocus class="form-control" name="symbol" placeholder="Share Symbol" type="text"/>
        </div>
         <div class="form-group">
            <input autocomplete="off" class="form-control" name="share_amt" placeholder="No. of Shares(optional)" type="number" min="1" />
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit">
                <span aria-hidden="true" class="glyphicon glyphicon-log-in"></span>
                Search
            </button>
        </div>
    </fieldset>
</form>
