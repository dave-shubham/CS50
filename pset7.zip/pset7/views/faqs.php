     <fieldset>
        <div class="form-group">
            <div>
            <h2>To get quote of a share</h2>
            <p>Click on <a href="quote.php">Quote</a> or Quote tab in the Navigation bar.<br>
            Select the company for which you want to get quote<br>
            <a href="quote.php"><img alt="quote.php" src="/img/quote.png"/></a><br><br>
            Enter the number of shares (optional) and Click on Get Quote.<br>
            <a href="quote.php"><img alt="quote.php" src="/img/quote1.png"/></a><br><br>
            Quotation of 1 share and entered number of shares will be displayed.</p>
            <a href="quote.php"><img alt="quote.php" src="/img/quote2.png"/></a>
            </div>
            <br><br>
            <div>
            <h2>To buy shares of a company</h2>
            <p>Click on <a href="buy.php">Buy</a> or Buy tab in the Navigation bar.<br>
            Select the company for which you want to buy the shares.<br>
            <a href="buy.php"><img alt="buy.php" src="/img/buy.png"/></a><br><br>
            Enter the number of shares you want to buy and Click on Buy.</p>
            <a href="buy.php"><img alt="buy.php" src="/img/buy1.png"/></a>
            </div>
            </div>
            <br><br>
            <div>
            <h2>To sell shares you have</h2>
            <p>Click on <a href="sell.php">Sell</a> or Sell tab in the Navigation bar.<br>
            Select the company for which you want to sell the shares and Click on Sell.</p>
            <a href="sell.php"><img alt="sell.php" src="/img/sell.png"/></a>
            </div>
            <br><br>
            <div style="align:left">
            <h2>To see history of transactions</h2>
            <p>Click on <a href="history.php">History</a> or History tab in the Navigation bar and<br>
            the page will display all the transactions in order of their occurence.</p>
            <a href="history.php"><img alt="history.php" src="/img/history.png"/></a>
            </div>
            <br><br>
            <div style="align:left">
            <h2>To change password</h2>
            <p>Click on <a href="password.php">Change Password</a> or Change Password tab in the Navigation bar.<br>
            Enter the current, new and confirmation for new password and click on Change Password.</p>
            <a href="password.php"><img alt="password.php" src="/img/password.png"/></a>
            </div>
        </div>
    </fieldset>
