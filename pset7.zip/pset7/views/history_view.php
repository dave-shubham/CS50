<div id="middle">
    <table class="table table-striped">
    <thead>
        <tr>
            <th>Transaction</th>
            <th>Symbol</th>
            <th>No. of Shares</th>
            <th>Price</th>
            <th>Date & Time</th>
        </tr>
    </thead>
    <tbody>
       <?php

        foreach ($transactions as $transaction)
        {
            $date=date_create($transaction["date_time"]);
            print("<tr>");
            print("<td>" . $transaction["trans_type"] . "</td>");
            print("<td>" . $transaction["symbol"] . "</td>");
            print("<td>" . $transaction["share_amt"] . "</td>");
            print("<td>" . money_format("$%i", $transaction["price"]) . "</td>");
            print("<td>" . date_format($date,"H:i:s d/m/Y") . "</td>");
            print("</tr>");
        }

    ?>
    </tbody>
</table>
</div>