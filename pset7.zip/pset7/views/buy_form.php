<form action="buy.php" method="post">
     <fieldset>
        <div class="form-group">
            <select class="form-control" name="symbol">
                <option disabled selected hidden value="">Company Name</option>
                <?php
                foreach ($positions as $position)
                {
                    print("<option value='".$position['symbol']."'>".$position['name']."</option>\n");
                }
                ?>
                </select>
        </div>
        <div class="form-group">
            <input autocomplete="off" class="form-control" name="share_amt" placeholder="No. of Shares" type="number" min="1" />
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit">
                <span aria-hidden="true" class="glyphicon glyphicon-log-in"></span>
                Buy
            </button>
        </div>
    </fieldset>
</form>