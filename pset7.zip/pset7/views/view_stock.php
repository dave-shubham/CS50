<form action="quote.php" method="post">
    <fieldset>
        <table style="margin: auto; text-align:right width: 50%; ">
        <tr>
        <div class="form-group">
            <td style="text-align:right">Symbol :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td><input type="text" class="form-control" name="symbol" readonly value=<?php echo $symbol; ?> /></td>
        </div>
        </tr>
        <tr>
        <div class="form-group">
            <td style="text-align:right"style="text-align:right">Share Name :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td><input type="text" class="form-control" name="name" readonly value=<?php echo $name; ?>/></td>
        </div>
        </tr>
        <tr>
        <div class="form-group">
            <td style="text-align:right">Price of 1 Share :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td><input type="text" class="form-control" name="price" readonly value=
                <?php echo money_format("$%i", $price);?>      /></td>
        </div>
        </tr>
        <tr>
        <div class="form-group">
            <td style="text-align:right">Total Price of <?php echo $_POST["share_amt"];?> Shares :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td><input type="text" class="form-control" name="total" readonly value=
            <?php echo money_format("$%i", $total);?>          /></td>
        </div>
        </tr>
        <tr>
        <div class="form-group">
            <td style="text-align:right">Max. buyable share quantity :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td><input type="text" class="form-control" name="canBuy" readonly value=
            <?php echo $canBuy;?>          /></td>
        </div>
        </tr>

        </table>
    </fieldset>
</form>
<div>
    <br>
    or <a href="quote.php">get another quote</a>
</div>
